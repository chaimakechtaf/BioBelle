package com.example.myapplication;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class ProductView extends RelativeLayout
{
    public static ProductView create(ViewGroup parent)
    {
        LayoutInflater li = LayoutInflater.from(parent.getContext());
        ProductView itemView = (ProductView) li.inflate(R.layout.item_product, parent,
                false);
        itemView.findViews();
        return itemView;
    }
    private ImageView ivImage;
    private TextView tvintitule;
    private TextView tvprix;
    private void findViews()
    {
        ivImage = (ImageView) findViewById(R.id.item_product_image);
        tvintitule = (TextView) findViewById(R.id.item_product_intitule);
        tvprix =(TextView) findViewById(R.id.item_product_prix);
    }
    public void display(final Product product)
    {
        ivImage.setImageResource(product.getId_image());
        tvintitule.setText(product.get_intitule());
        tvprix.setText(Float.toString(product.getP_prix()));
    }
    /** constructeur */

    public ProductView(Context context, AttributeSet attrs)
    {
        super(context, attrs);
    }
    /** constructeur */
    public ProductView(Context context, AttributeSet attrs, int defStyle)
    {
        super(context, attrs, defStyle);
    }

}

