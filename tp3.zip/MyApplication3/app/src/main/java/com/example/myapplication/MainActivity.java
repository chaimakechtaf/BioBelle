package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ListActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends ListActivity {
    protected ArrayList<Product> products;
    private ArrayAdapter adapter;
    private static final int RQ_CODE_EDITION = 1;
    protected ArrayList<Product> mListe;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        MyApplication context = (MyApplication) this.getApplicationContext();
        mListe = context.initData();




       ProductAdapter adapter = new ProductAdapter(this, mListe);
        ListView lv = (ListView) findViewById(android.R.id.list);
        lv.setAdapter(adapter);




    }
}
