package com.example.myapplication;

public class Product {
    public String p_intitule;
    public float p_prix;
    public int id_image;


    public Product(String p_intitule,float p_prix,int id_image){
        this.p_intitule=p_intitule;
        this.p_prix=p_prix;
        this.id_image=id_image;
    }
    @Override
    public String toString(){
        return p_intitule+Float.toString(p_prix)+"dh";
    }

    public int getId_image() {
        return id_image;
    }

    public String get_intitule() {
        return p_intitule;
    }

    public float getP_prix() {
        return p_prix;
    }
}
