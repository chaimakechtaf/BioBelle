package com.example.examen;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;
import java.util.List;

public class ListActivity extends AppCompatActivity {

    private ListView listView;
    private DatabaseReference ListDatabaseRef;
    private List<Product> productList;
    private ListAdapter adapter;
    private List<Product> filteredList;

    private SearchView searchView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);


        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigationView);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                int id = menuItem.getItemId();

                if (id == R.id.Add) {
                    Intent intent = new Intent(ListActivity.this, AddActivity.class);
                    startActivity(intent);
                    finish();
                }

                if (id == R.id.List) {
                    Intent intent = new Intent(ListActivity.this, ListActivity.class);
                    startActivity(intent);
                    finish();
                }

                if (id == R.id.Map) {
                    Intent intent = new Intent(ListActivity.this, MapActivity.class);
                    startActivity(intent);
                    finish();
                }

                return true;
            }
        });


        ListDatabaseRef = FirebaseDatabase.getInstance().getReference().child("products");

        listView = findViewById(R.id.listView);
        searchView = findViewById(R.id.searchEditText);

        productList = new ArrayList<>();
        filteredList = new ArrayList<>();

        adapter = new ListAdapter(this, filteredList);
        listView.setAdapter(adapter);

        // Fetch data from Firebase
        fetchFavoriteItems();

        // Set item click listener
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // Handle item click, get the selected product
                Product selectedProduct = filteredList.get(position);

                // Start AffichActivity and pass the selected product details
                Intent intent = new Intent(ListActivity.this, AffichActivity.class);
                intent.putExtra("productName", selectedProduct.getName());
                intent.putExtra("productPrice", selectedProduct.getPrice());
                intent.putExtra("productImageUrl", selectedProduct.getImageUrl());
                startActivity(intent);
            }
        });

        // Set up the search functionality
        setupSearchView();
    }

    private void setupSearchView() {
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                // Filter the list based on the search query
                filterList(newText);
                return true;
            }
        });
    }

    private void filterList(String query) {
        filteredList.clear();

        for (Product product : productList) {
            if (product.getName().toLowerCase().contains(query.toLowerCase())) {
                filteredList.add(product);
            }
        }

        adapter.notifyDataSetChanged();
    }

    private void fetchFavoriteItems() {
        ListDatabaseRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                productList.clear();
                for (DataSnapshot child : snapshot.getChildren()) {
                    try {
                        Product product = child.getValue(Product.class);
                        if (product != null) {
                            productList.add(product);
                        }
                    } catch (Exception e) {
                        // Handle error converting data
                    }
                }
                // Initially, show all products in the adapter
                filteredList.clear();
                filteredList.addAll(productList);
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Handle Firebase error
            }
        });
    }
}

