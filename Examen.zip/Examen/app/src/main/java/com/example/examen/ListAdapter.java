package com.example.examen;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.squareup.picasso.Picasso;

import java.util.List;

public class ListAdapter extends ArrayAdapter<Product> {

    public ListAdapter(Context context, List<Product> products) {
        super(context, 0, products);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View listItemView = convertView;
        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(
                    R.layout.list_items, parent, false);
        }

        Product currentProduct = getItem(position);

        ImageView productImage = listItemView.findViewById(R.id.imageView);
        Picasso.get().load(currentProduct.getImageUrl()).into(productImage);

        TextView textProductName = listItemView.findViewById(R.id.textViewName);
        textProductName.setText(currentProduct.getName());

        TextView textPrice = listItemView.findViewById(R.id.textViewPrice);
        textPrice.setText(currentProduct.getPrice());

        return listItemView;
    }


}
