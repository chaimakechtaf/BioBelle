package com.example.examen;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import org.checkerframework.checker.units.qual.A;

public class AddActivity extends Activity {

    private static final int PICK_FILE_REQUEST = 1;
    private ImageView imageViewProduct;
    private EditText nameEditText;
    private EditText priceEditText;
    private DatabaseReference databaseReference;
    private StorageReference storageReference;

    private Uri selectedImageUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigationView);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                int id = menuItem.getItemId();

                if (id == R.id.Add) {
                    Intent intent = new Intent(AddActivity.this, AddActivity.class);
                    startActivity(intent);
                    finish();
                }

                if (id == R.id.List) {
                    Intent intent = new Intent(AddActivity.this, ListActivity.class);
                    startActivity(intent);
                    finish();
                }

                if (id == R.id.Map) {
                    Intent intent = new Intent(AddActivity.this, MapActivity.class);
                    startActivity(intent);
                    finish();
                }

                if (id == R.id.contact) {
                    Intent intent = new Intent(AddActivity.this, FormulaireActivity.class);
                    startActivity(intent);
                    finish();
                }

                return true;
            }
        });

        imageViewProduct = findViewById(R.id.imageViewProduct);
        nameEditText = findViewById(R.id.nameEditText);
        priceEditText = findViewById(R.id.priceEditText);
        Button btnAddimg = findViewById(R.id.btnAddimg);
        Button uploadButton = findViewById(R.id.uploadButton);

        // Initialize Firebase
        databaseReference = FirebaseDatabase.getInstance().getReference("products");
        storageReference = FirebaseStorage.getInstance().getReference();

        btnAddimg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onSelectFileClick();
            }
        });

        uploadButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                uploadProduct();
            }
        });


    }

    private void navigateToActivity(Class<?> destinationActivity) {
        Intent intent = new Intent(AddActivity.this, destinationActivity);
        startActivity(intent);
        finish();
    }

    public void onSelectFileClick() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("image/*");
        startActivityForResult(intent, PICK_FILE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_FILE_REQUEST && resultCode == RESULT_OK) {
            if (data != null) {
                selectedImageUri = data.getData();
                imageViewProduct.setImageURI(selectedImageUri);
            }
        }
    }

    private void uploadProduct() {
        String name = nameEditText.getText().toString().trim();
        String price = priceEditText.getText().toString().trim();

        if (!name.isEmpty() && !price.isEmpty() && selectedImageUri != null) {
            price = price + " MAD";
            Product product = new Product(name, price);

            // Generate a unique key for the product
            String productId = databaseReference.push().getKey();

            // Upload image to Firebase Storage
            StorageReference imageRef = storageReference.child("images/" + productId + ".jpg");
            UploadTask uploadTask = imageRef.putFile(selectedImageUri);

            uploadTask.addOnSuccessListener(taskSnapshot -> {
                // Image uploaded successfully, get the download URL
                imageRef.getDownloadUrl().addOnSuccessListener(uri -> {
                    String imageUrl = uri.toString();
                    product.setImageUrl(imageUrl);

                    // Save the product to the database with the generated key
                    databaseReference.child(productId).setValue(product);

                    // Clear the fields
                    nameEditText.setText("");
                    priceEditText.setText("");
                    imageViewProduct.setImageResource(android.R.color.transparent);

                    showToast("Product added successfully!");
                });
            }).addOnFailureListener(e -> {
                // Handle errors during image upload
                showToast("Failed to upload image");
            });
        } else {
            showToast("Fields are required!");
        }
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
