package com.example.examen;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.squareup.picasso.Picasso;

public class AffichActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_affich);

        // Retrieve data passed from ListActivity
        Intent intent = getIntent();
        String productName = intent.getStringExtra("productName");
        String productPrice = intent.getStringExtra("productPrice");
        String productImageUrl = intent.getStringExtra("productImageUrl");

        // Set the retrieved data to TextViews and ImageView
        TextView textViewProductName = findViewById(R.id.textViewProductName);
        TextView textViewProductPrice = findViewById(R.id.textViewProductPrice);
        ImageView imageViewProduct = findViewById(R.id.imageViewProduct);

        textViewProductName.setText("Name: " + productName);
        textViewProductPrice.setText("Price: " + productPrice);

        // Load image using Picasso
        Picasso.get().load(productImageUrl).into(imageViewProduct);
    }
}
