package com.example.beautyandcosmetics;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class DeliveryActivity extends AppCompatActivity {

    private EditText editTextFullName;
    private EditText editTextEmail;
    private EditText editTextPhone;
    private EditText editTextAddress;
    private Spinner spinnerCity;
    private TextView TotalProd;
    private TextView TotalPrice;

    // Firebase
    private DatabaseReference checkoutRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.delivery);

        editTextFullName = findViewById(R.id.etFullName);
        editTextEmail = findViewById(R.id.etEmail);
        editTextPhone = findViewById(R.id.etPhone);
        editTextAddress = findViewById(R.id.etAddress);
        spinnerCity = findViewById(R.id.spinnerCity);
        TotalProd = findViewById(R.id.TotalProd);
        TotalPrice = findViewById(R.id.TotalPrice);

        String[] cityOptions = {"Choose your City...", "Agadir", "Casablanca", "Fes", "Rabat", "Marrakech", "Tanger", "Taroudannt"};

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, cityOptions);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spinnerCity.setAdapter(adapter);

        // Initialize Firebase
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        checkoutRef = database.getReference("checkout");

        Button buttonSubmit = findViewById(R.id.confirmButton);
        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String fullName = editTextFullName.getText().toString();
                String email = editTextEmail.getText().toString();
                String phone = editTextPhone.getText().toString();
                String address = editTextAddress.getText().toString();
                String city = spinnerCity.getSelectedItem().toString();
                String product = TotalProd.getText().toString();
                String price = TotalPrice.getText().toString();

                // Basic input validation
                if (TextUtils.isEmpty(fullName) || TextUtils.isEmpty(email) || TextUtils.isEmpty(phone) ||
                        TextUtils.isEmpty(address) || TextUtils.isEmpty(city)) {
                    // Show an error message if any field is empty
                    Toast.makeText(DeliveryActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Create a Checkout object with the collected data
                Checkout checkout = new Checkout(fullName, email, phone, address, city, product, price);

                // Save the Checkout object to Firebase
                checkoutRef.push().setValue(checkout)
                        .addOnCompleteListener(DeliveryActivity.this, task -> {
                            if (task.isSuccessful()) {
                                // Data successfully inserted into Firebase
                                String message = "Your order has been successfully registered. Thank you!";
                                Toast.makeText(DeliveryActivity.this, message, Toast.LENGTH_SHORT).show();
                            } else {
                                // Failed to insert data into Firebase
                                String errorMessage = "Failed to register your order. Please try again.";
                                Toast.makeText(DeliveryActivity.this, errorMessage, Toast.LENGTH_SHORT).show();
                            }
                        });
            }
        });

        ImageView backButton = findViewById(R.id.back);
        backButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View btn) {
                Intent i = new Intent(DeliveryActivity.this, CartActivity.class);
                startActivity(i);
            }
        });
    }
}
