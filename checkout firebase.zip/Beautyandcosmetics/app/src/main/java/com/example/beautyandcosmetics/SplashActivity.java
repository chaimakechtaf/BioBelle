package com.example.beautyandcosmetics;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import androidx.appcompat.app.AppCompatActivity;

public class SplashActivity extends AppCompatActivity {

    // Durée d'affichage du logo en millisecondes (5 secondes)
    private static final int SPLASH_TIME_OUT = 1500;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        // Utilisation d'un Handler pour retarder le passage à l'écran suivant
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                // Créer une intention pour passer à l'écran d'accueil
                Intent homeIntent = new Intent(SplashActivity.this, MainActivity.class);
                startActivity(homeIntent);
                finish(); // Ferme l'activité actuelle pour éviter de revenir à cet écran avec le bouton "Retour"
            }
        }, SPLASH_TIME_OUT);
    }
}
