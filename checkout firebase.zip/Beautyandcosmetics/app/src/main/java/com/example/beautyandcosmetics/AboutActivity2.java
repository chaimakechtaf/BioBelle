package com.example.beautyandcosmetics;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;

import com.google.android.material.navigation.NavigationView;

public class AboutActivity2 extends Activity {

    private DrawerLayout drawerLayout; // Déclarez DrawerLayout


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about2);

        drawerLayout = findViewById(R.id.drawer_layout); // Initialisez DrawerLayout

        ImageView btn = findViewById(R.id.shopping_cart_icon);

        btn.setOnClickListener(
                new View.OnClickListener(){;
                    public void onClick (View btn) {
                        Intent i = new Intent(AboutActivity2.this, CartActivity.class);
                        startActivity(i);
                    }
                });

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(MenuItem menuItem) {
                // Vérifiez l'ID de l'élément de menu sélectionné
                int id = menuItem.getItemId();

                if (id == R.id.nav_shop) {
                    // L'élément "Home" a été sélectionné, redirigez vers la page "Home"
                    Intent intent = new Intent(AboutActivity2.this, ArganaActivity.class);
                    startActivity(intent);
                }



                if (id == R.id.nav_home) {
                    // L'élément "Home" a été sélectionné, redirigez vers la page "Home"
                    Intent intent = new Intent(AboutActivity2.this, MainActivity.class);
                    startActivity(intent);
                }

                if (id == R.id.nav_like) {
                    // L'élément "Home" a été sélectionné, redirigez vers la page "Home"
                    Intent intent = new Intent(AboutActivity2.this, FavoriteActivity.class);
                    startActivity(intent);
                }

                drawerLayout.closeDrawer(GravityCompat.START); // Fermez le menu après la sélection

                return true;
            }
        });

        ImageView sidebarImage = findViewById(R.id.sidebar);
        sidebarImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Ouvrez le menu de navigation lorsque l'image sidebar est cliquée
                drawerLayout.openDrawer(GravityCompat.START);
            }
        });


    }
}