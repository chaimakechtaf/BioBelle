package com.example.beautyandcosmetics;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;

import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;

public class FavoriteActivity extends Activity {

    private DrawerLayout drawerLayout; // Déclarez DrawerLayout


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.favorite);


        drawerLayout = findViewById(R.id.drawer_layout); // Initialisez DrawerLayout


        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(MenuItem menuItem) {
                // Vérifiez l'ID de l'élément de menu sélectionné
                int id = menuItem.getItemId();


                if (id == R.id.nav_home) {
                    // L'élément "Home" a été sélectionné, redirigez vers la page "Home"
                    Intent intent = new Intent(FavoriteActivity.this, MainActivity.class);
                    startActivity(intent);
                }

                if (id == R.id.nav_shop) {
                    // L'élément "Home" a été sélectionné, redirigez vers la page "Home"
                    Intent intent = new Intent(FavoriteActivity.this, ArganaActivity.class);
                    startActivity(intent);
                }

                if (id == R.id.nav_about_us) {
                    // L'élément "Home" a été sélectionné, redirigez vers la page "Home"
                    Intent intent = new Intent(FavoriteActivity.this, AboutActivity2.class);
                    startActivity(intent);
                }



                drawerLayout.closeDrawer(GravityCompat.START); // Fermez le menu après la sélection


                return true;
            }
        });

        ImageView shoppingCartButton = findViewById(R.id.shopping_cart_icon);
        shoppingCartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Redirigez vers CartActivity lorsque le bouton est cliqué
                Intent intent = new Intent(FavoriteActivity.this, CartActivity.class);
                startActivity(intent);
            }
        });


        ImageView sidebarImage = findViewById(R.id.sidebar);
        sidebarImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Ouvrez le menu de navigation lorsque l'image sidebar est cliquée
                drawerLayout.openDrawer(GravityCompat.START);
            }
        });
    }


}










