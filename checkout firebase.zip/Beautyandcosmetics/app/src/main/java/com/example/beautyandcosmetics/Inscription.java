package com.example.beautyandcosmetics;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Inscription extends Activity {

    private static final int PICK_FILE_REQUEST = 1;
    private EditText editTextFilePath;
    private EditText nameEditText;
    private EditText brandEditText;
    private EditText priceEditText;
    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.inscription);

        editTextFilePath = findViewById(R.id.editTextFilePath);
        nameEditText = findViewById(R.id.nameEditText);
        brandEditText = findViewById(R.id.brandEditText);
        priceEditText = findViewById(R.id.priceEditText);
        Button uploadButton = findViewById(R.id.uploadButton);

        // Initialize Firebase
        databaseReference = FirebaseDatabase.getInstance().getReference("products");

        uploadButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                uploadProduct();
            }
        });
    }

    public void onSelectFileClick(View view) {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("*/*"); // Tous les types de fichiers
        startActivityForResult(intent, PICK_FILE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == PICK_FILE_REQUEST && resultCode == RESULT_OK) {
            if (data != null) {
                Uri uri = data.getData();
                String filePath = uri.getPath(); // Chemin du fichier sélectionné
                editTextFilePath.setText(filePath);
            }
        }
    }

    private void uploadProduct() {
        String name = nameEditText.getText().toString().trim();
        String brand = brandEditText.getText().toString().trim();
        String price = priceEditText.getText().toString().trim();
        String imageFilePath = editTextFilePath.getText().toString().trim();

        // Check if the fields are not empty
        if (!name.isEmpty() && !brand.isEmpty() && !price.isEmpty() && !imageFilePath.isEmpty()) {
            // Create a Product object
            Product product = new Product(name, brand, price, imageFilePath);

            // Push the product to the database
            String productId = databaseReference.push().getKey();
            databaseReference.child(productId).setValue(product);

            // Clear the fields
            nameEditText.setText("");
            brandEditText.setText("");
            priceEditText.setText("");
            editTextFilePath.setText("");

            // Inform the user that the product has been added successfully
            showToast("Product added successfully!");
        }    else {
            // Inform the user that fields are required
            showToast("Fields are required!");
        }
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

}
