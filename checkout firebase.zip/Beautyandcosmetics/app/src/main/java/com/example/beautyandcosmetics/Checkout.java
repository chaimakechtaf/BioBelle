package com.example.beautyandcosmetics;

public class Checkout {
    public String Full_Name;
    public String Email;
    public String Phone;
    public String Address;
    public String city;

    public String product;

    public String price;

    public Checkout() {
        // Default constructor required for calls to DataSnapshot.getValue(Checkout.class)
    }

    public Checkout(String Full_Name, String Email, String Phone, String Address, String city,String product,String price) {
        this.Full_Name = Full_Name;
        this.Email = Email;
        this.Phone = Phone;
        this.Address = Address;
        this.city = city;
        this.product=product;
        this.price=price;
    }
}

