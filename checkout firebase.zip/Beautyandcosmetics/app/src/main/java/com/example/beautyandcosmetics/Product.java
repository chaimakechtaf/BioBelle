package com.example.beautyandcosmetics;

public class Product {

    private String name;
    private String brand;
    private String price;
    private String imageFilePath;

    // Required default constructor for Firebase
    public Product() {
    }

    public Product(String name, String brand, String price, String imageFilePath) {
        this.name = name;
        this.brand = brand;
        this.price = price;
        this.imageFilePath = imageFilePath;
    }

    public String getName() {
        return name;
    }

    public String getBrand() {
        return brand;
    }

    public String getPrice() {
        return price;
    }

    public String getImageFilePath() {
        return imageFilePath;
    }
}
