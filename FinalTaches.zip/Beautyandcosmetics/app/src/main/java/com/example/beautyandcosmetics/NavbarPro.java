package com.example.beautyandcosmetics;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.beautyandcosmetics.R;

public class NavbarPro extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.navbar_pro);


     ImageView btn = findViewById(R.id.order);

        btn.setOnClickListener(
                new View.OnClickListener(){;
                    public void onClick (View btn) {
                        Intent i = new Intent(NavbarPro.this, OrderActivity.class);
                        startActivity(i);
                    }
                });

        ImageView products = findViewById(R.id.Products);
        products.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Redirigez vers CartActivity lorsque le bouton est cliqué
                Intent intent = new Intent(NavbarPro.this, ProductsActivity.class);
                startActivity(intent);
            }
        });

        ImageView home = findViewById(R.id.home);
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Redirigez vers CartActivity lorsque le bouton est cliqué
                Intent intent = new Intent(NavbarPro.this, Inscription.class);
                startActivity(intent);
            }
        });

    }
}