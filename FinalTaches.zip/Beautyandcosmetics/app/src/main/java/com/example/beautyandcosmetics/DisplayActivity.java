package com.example.beautyandcosmetics;

import android.content.Intent;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;
import com.squareup.picasso.Picasso;
import android.widget.Button;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
public class DisplayActivity extends AppCompatActivity {
    private boolean isLiked = false;
    private int quantity = 1; // Initial quantity
    private DatabaseReference cartDatabaseRef;

    private ImageView likeButton;
    private TextView quantityTextView;

    private DrawerLayout drawerLayout; // Déclarez DrawerLayout

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.display_product);

        likeButton = findViewById(R.id.likeIcon);
        quantityTextView = findViewById(R.id.quantity);

        likeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Inversez l'état de like pour le premier bouton "like".
                isLiked = !isLiked;

                // Appliquez la teinte rouge si l'icône est "aimé", sinon réinitialisez la couleur.
                if (isLiked) {
                    likeButton.setColorFilter(getResources().getColor(R.color.redColor), PorterDuff.Mode.SRC_IN);
                } else {
                    likeButton.setColorFilter(null); // Réinitialisez la couleur
                }
            }
        });

        ImageView moinsButton = findViewById(R.id.moins);
        ImageView plusButton = findViewById(R.id.plus);

        moinsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Decrease quantity
                if (quantity > 1) {
                    quantity--;
                    quantityTextView.setText(String.valueOf(quantity));
                }
            }
        });

        plusButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Increase quantity
                quantity++;
                quantityTextView.setText(String.valueOf(quantity));
            }
        });

        drawerLayout = findViewById(R.id.drawer_layout);

        ImageView btn = findViewById(R.id.shopping_cart_icon);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View btn) {
                Intent i = new Intent(DisplayActivity.this, CartActivity.class);
                startActivity(i);
            }
        });

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(MenuItem menuItem) {
                int id = menuItem.getItemId();

                if (id == R.id.nav_about_us) {
                    Intent intent = new Intent(DisplayActivity.this, AboutActivity2.class);
                    startActivity(intent);
                }

                if (id == R.id.nav_shop) {
                    Intent intent = new Intent(DisplayActivity.this, ShopActivity.class);
                    startActivity(intent);
                }

                if (id == R.id.nav_home) {
                    Intent intent = new Intent(DisplayActivity.this, MainActivity.class);
                    startActivity(intent);
                }

                if (id == R.id.nav_like) {
                    Intent intent = new Intent(DisplayActivity.this, FavoriteActivity.class);
                    startActivity(intent);
                }

                drawerLayout.closeDrawer(GravityCompat.START);

                return true;
            }
        });

        ImageView sidebarImage = findViewById(R.id.sidebar);
        sidebarImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawerLayout.openDrawer(GravityCompat.START);
            }
        });

        // Retrieve data from the intent
        Intent intent = getIntent();
        String productName = intent.getStringExtra("productName");
        String productBrand = intent.getStringExtra("productBrand");
        String productPrice = intent.getStringExtra("productPrice");
        String productImageURL = intent.getStringExtra("productImage");

        // Set data in the corresponding views
        TextView productNameTextView = findViewById(R.id.productName);
        TextView productPriceTextView = findViewById(R.id.productPrice);
        ImageView productImageView = findViewById(R.id.productImage);

        productNameTextView.setText(productName);
        productPriceTextView.setText(productPrice);

        // Use Picasso to load the image from the URL
        Picasso.get().load(productImageURL).into(productImageView);




        // Initialize Firebase Database reference
        cartDatabaseRef = FirebaseDatabase.getInstance().getReference().child("cart");

        // Modify the onClick listener for the "ADD TO CART" button
        Button addToCartButton = findViewById(R.id.addToCartButton);
        addToCartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Create a unique key for the cart item
                String cartItemId = cartDatabaseRef.push().getKey();

                // Get product details from intent
                String productName = getIntent().getStringExtra("productName");
                String productBrand = getIntent().getStringExtra("productBrand");
                String productPrice = getIntent().getStringExtra("productPrice");
                String productImageURL = getIntent().getStringExtra("productImage");

                // Create a CartItem object
                CartItem cartItem = new CartItem(cartItemId, productName, productBrand, productPrice, productImageURL, quantity);

                // Add the cart item to the Firebase Realtime Database
                cartDatabaseRef.child(cartItemId).setValue(cartItem);

                // Provide feedback to the user (you can customize this part)
                Toast.makeText(DisplayActivity.this, "Product added to cart!", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
