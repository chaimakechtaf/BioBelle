package com.example.beautyandcosmetics;


import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class ShopActivity extends AppCompatActivity {

    private GridView gridView;
    private DrawerLayout drawerLayout;
    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shop);

        // Initialize Firebase
        databaseReference = FirebaseDatabase.getInstance().getReference("products");

        // Exemple de données
        List<ShopItem> productList = new ArrayList<>();

        // Read data from Firebase
        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    ShopItem product = snapshot.getValue(ShopItem.class);
                    productList.add(product);
                }

                // Update the GridView after retrieving data
                updateGridView(productList);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Handle error
            }
        });

        // Initialize DrawerLayout
        drawerLayout = findViewById(R.id.drawer_layout);

        ImageView btn = findViewById(R.id.shopping_cart_icon);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(ShopActivity.this, CartActivity.class);
                startActivity(i);
            }
        });

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                int id = menuItem.getItemId();

                if (id == R.id.nav_about_us) {
                    Intent intent = new Intent(ShopActivity.this, AboutActivity2.class);
                    startActivity(intent);
                }

                if (id == R.id.nav_home) {
                    Intent intent = new Intent(ShopActivity.this, MainActivity.class);
                    startActivity(intent);
                }

                if (id == R.id.nav_like) {
                    Intent intent = new Intent(ShopActivity.this, FavoriteActivity.class);
                    startActivity(intent);
                }

                drawerLayout.closeDrawer(GravityCompat.START);
                return true;
            }
        });

        ImageView sidebarImage = findViewById(R.id.sidebar);
        sidebarImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawerLayout.openDrawer(GravityCompat.START);
            }
        });
    }

    private void updateGridView(List<ShopItem> productList) {
        // Create an adapter
        ShopAdapter adapter = new ShopAdapter(this, productList);

        // Configure the GridView with GridLayout
        GridView gridView = findViewById(R.id.gridView);
        gridView.setAdapter(adapter);
        gridView.setNumColumns(2);

        // Add a click listener on the items of the GridView
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // Get the selected item from the adapter
                ShopItem selectedItem = (ShopItem) parent.getItemAtPosition(position);

                // Create an intent to display DisplayActivity with the data of the selected item
                Intent intent = new Intent(ShopActivity.this, DisplayActivity.class);
                intent.putExtra("productName", selectedItem.getName());
                intent.putExtra("productPrice", selectedItem.getPrice());
                intent.putExtra("productImage", selectedItem.getImageUrl()); // Use the image URL here
                startActivity(intent);
            }
        });

        // Load images into ImageView using Picasso
        for (int i = 0; i < gridView.getChildCount(); i++) {
            ImageView imageView = (ImageView) gridView.getChildAt(i).findViewById(R.id.imageView); // Assuming you have an ImageView in your grid item layout
            Picasso.get().load(productList.get(i).getImageUrl()).into(imageView);
        }
    }
}