package com.example.beautyandcosmetics;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class OrderActivity extends AppCompatActivity {

    private DatabaseReference checkoutRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.order);

        ImageView btn = findViewById(R.id.order);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(OrderActivity.this, OrderActivity.class);
                startActivity(i);
            }
        });

        ImageView products = findViewById(R.id.Products);
        products.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(OrderActivity.this, ProductsActivity.class);
                startActivity(intent);
            }
        });

        ImageView home = findViewById(R.id.home);
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(OrderActivity.this, Inscription.class);
                startActivity(intent);
            }
        });

        // Initialize Firebase
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        checkoutRef = database.getReference("checkout");

        // Fetch data from Firebase and populate the table
        populateTable();
    }

    private void populateTable() {
        TableLayout tableLayout = findViewById(R.id.tableLayout);

        // Add a listener to fetch data from Firebase
        checkoutRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // Clear existing rows
                tableLayout.removeAllViews();

                // Iterate through the data from Firebase
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    Checkout checkout = snapshot.getValue(Checkout.class);

                    // Create a new row
                    TableRow tableRow = new TableRow(OrderActivity.this);

                    // Add TextViews for each column
                    addTextViewToRow(tableRow, checkout.getFull_Name());
                    addTextViewToRow(tableRow, checkout.getPhone());
                    addTextViewToRow(tableRow, checkout.getEmail());
                    addTextViewToRow(tableRow, checkout.getAddress());
                    addTextViewToRow(tableRow, checkout.getCity());
                    addTextViewToRow(tableRow, checkout.getTotalProducts());
                    addTextViewToRow(tableRow, String.format("%.2f MAD", checkout.getTotalPrice()));

                    // Add the row to the table
                    tableLayout.addView(tableRow);
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Handle errors here
            }
        });
    }

    private void addTextViewToRow(TableRow tableRow, String text) {
        TextView textView = new TextView(OrderActivity.this);
        textView.setText(text);
        textView.setPadding(8, 8, 8, 8);
        tableRow.addView(textView);
    }
}
